from django.shortcuts import render,redirect
import requests
import pandas
from bs4 import BeautifulSoup
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout
from booksapp.models import useradd,contact
from django.contrib.auth.decorators import login_required

@login_required(login_url='login')
def home(request):
    return render(request,"base.html")

def products(request):
    return render(request,"products.html")


response=requests.get("https://www.flipkart.com/search?q=swami+vivekananda+books+in+english&as=on&as-show=on&otracker=AS_Query_OrganicAutoSuggest_8_18_na_na_ps&otracker1=AS_Query_OrganicAutoSuggest_8_18_na_na_ps&as-pos=8&as-type=RECENT&suggestionId=swami+vivekananda+books+in+english&requestId=95ecc219-2341-4b8a-a4aa-b2a000283f6d&as-searchtext=vivekananda%20books%20")
print(response)
soup=BeautifulSoup(response.content,"html.parser")

names=soup.find_all('a',class_="s1Q9rs")
name=[]
for i in names[0:10]:
    name.append(i.get_text())



prices=soup.find_all('div',class_="_30jeq3")
price=[]
for i in prices[0:10]:
    price.append(i.get_text())

images=soup.find_all('img',class_="_396cs4")
image=[]
for i in images[0:10]:
    image.append(i['src'])


links=soup.find_all('a',class_="s1Q9rs")
link=[]
for i in links[0:10]:
    d='https://www.flipkart.com'+i['href']
    link.append(d)

mylist1=zip(name,
price,
image,
link
)

def vivak(request):
    return render(request,"vivak.html",{'mylist1':mylist1})


response=requests.get("https://www.flipkart.com/search?q=apj+abdul+kalam+books+in+english&sid=bks&as=on&as-show=on&otracker=AS_QueryStore_OrganicAutoSuggest_1_28_na_na_ps&otracker1=AS_QueryStore_OrganicAutoSuggest_1_28_na_na_ps&as-pos=1&as-type=RECENT&suggestionId=apj+abdul+kalam+books+in+english%7CBooks&requestId=6b18c5d6-6bf4-451d-84f8-8fbb4aee975f&as-searchtext=abdul%20kalam%20books%20in%20english")
print(response)
soup=BeautifulSoup(response.content,"html.parser")

names=soup.find_all('a',class_="s1Q9rs")
name=[]
for i in names[0:10]:
    name.append(i.get_text())
print(name)


prices=soup.find_all('div',class_="_30jeq3")
price=[]
for i in prices[0:10]:
    price.append(i.get_text())
print(price)

images=soup.find_all('img',class_="_396cs4")
image=[]
for i in images[0:10]:
    image.append(i['src'])
print(image)

links=soup.find_all('a',class_="s1Q9rs")
link=[]
for i in links[0:10]:
    d='https://www.flipkart.com'+i['href']
    link.append(d)
print(link)

mylist2=zip(name,
price,
image,
link
)

def abdul(request):
    return render(request,"abdul.html",{'mylist2':mylist2})

response=requests.get("https://www.flipkart.com/search?q=bhagavad+gita%2Cramayanam%2Cbuble+books+in+english&otracker=search&otracker1=search&marketplace=FLIPKART&as-show=on&as=off&as-pos=1&as-type=HISTORY")
print(response)
soup=BeautifulSoup(response.content,"html.parser")

names=soup.find_all('a',class_="s1Q9rs")
name=[]
for i in names[0:10]:
    name.append(i.get_text())
print(name)


prices=soup.find_all('div',class_="_30jeq3")
price=[]
for i in prices[0:10]:
    price.append(i.get_text())
print(price)

images=soup.find_all('img',class_="_396cs4")
image=[]
for i in images[0:10]:
    image.append(i['src'])
print(image)

links=soup.find_all('a',class_="s1Q9rs")
link=[]
for i in links[0:10]:
    d='https://www.flipkart.com'+i['href']
    link.append(d)
print(link)

mylist3=zip(name,
price,
image,
link
)

def abdul(request):
    return render(request,"abdul.html",{'mylist3':mylist3})

def login_user(request):
    if request.method=='POST':
        Username=request.POST.get('username')
        Password=request.POST.get('password')
        user=authenticate(Username=Username,Password=Password)
        if user is not None:
            login(request,user)
        return redirect("home")
    return render(request,"login.html")


def register(request):
    if request.method=="POST":
        Username=request.POST.get("Username")
        Password=request.PosT.get("password")
        email=request.POST.get("email")
        c=User.objects.create_user(Username=Username, email=email, password=Password)
        c.save()
        return redirect("login")
    
    return render(request,"register.html")

   


def logout_user(request):
    logout(request)
    return redirect("login")

def contact(request):
    if request.method=="POST":
        name=request.POST['name']
        email=request.POST['email']
        message=request.POST['message']

        c=contact(name=name,email=email,message=message)
        c.save()
        return redirect("home")
    return render(request,"contact.html")



